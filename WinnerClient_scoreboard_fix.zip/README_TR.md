# WinnerClient scoreboard NameHider fix

This patch replaces the unavailable `net.minecraft.client.gui.hud.ScoreboardHud`
type with Yarn's `net.minecraft.client.gui.hud.InGameHud`.

## Apply
1. Copy `src/main/java/.../ScoreboardHudMixin.java` into the matching source path.
2. Open `src/main/resources/winnerclient.mixins.json`.
3. Add `ScoreboardHudMixin` to its `client` array (once only).
4. Remove any previous mixin that imports `ScoreboardHud`.

`require = 0` prevents startup failure if the exact draw invocation differs in
your mapped build. If the scoreboard text still is not replaced at runtime,
send the full Gradle/Mixin log so the injection point can be matched to the
actual 1.21.11 bytecode.
