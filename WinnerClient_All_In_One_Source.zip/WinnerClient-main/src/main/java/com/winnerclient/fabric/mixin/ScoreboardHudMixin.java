package com.winnerclient.fabric.mixin;

import com.winnerclient.fabric.module.player.NameHider;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ScoreboardHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** Applies NameHider to text rendered by the sidebar scoreboard. */
@Mixin(ScoreboardHud.class)
public abstract class ScoreboardHudMixin {
    @ModifyArg(
        method = "renderScoreboardSidebar",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)I"
        ),
        index = 1
    )
    private Text winnerclient$hideScoreboardNames(Text text) {
        return NameHider.replace(text);
    }
}
