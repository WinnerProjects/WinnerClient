# WinnerClient — All-in-one kaynak paketi

Bu paket, WinnerClient projesinin kaynak kodunu ve şu değişikliği içerir:

## Bu pakette uygulanmış değişiklik
- NameHider için `ScoreboardHudMixin` eklendi ve `winnerclient.mixins.json` içine kaydedildi. Scoreboard sidebar metinleri de NameHider.replace() üzerinden geçirilir.

## Port referansları (henüz entegre değil)
- Donut SeedESP / seed tabanlı cevher tahmini kaynakları: `PORT_REFERENCE_ONLY/DonutClient/.../blockesp/`
- Donut SoundNotifier / Sound Detector kaynakları: `PORT_REFERENCE_ONLY/DonutClient/.../sound/` ve ilişkili config/gui/mixin klasörleri.

Bu iki özellik henüz WinnerClient'ın Yarn 1.21.11 API'sine çevrilip ModuleManager'a bağlanmış değildir. Donut kaynakları Mojang mappings kullandığından olduğu gibi ana kaynaklara eklenirse derlenmez. Referans kodu ayrı tutuldu; tamamlanmış port olduğu iddia edilmiyor.

## Derleme
Projeyi normal WinnerClient yöntemiyle açıp `./gradlew build` çalıştırın. Bu pakette NameHider mixin'i için bağımsız Gradle derleme doğrulaması yapılmadı; derleme hatası çıkarsa tam hata çıktısını paylaşın.

## Lisans
Donut kaynak referansları kendi `PORT_REFERENCE_ONLY/DonutClient/LICENSE` dosyasıyla birlikte tutulur. Kaynakları kullanırken ilgili telif ve lisans koşullarını koruyun.
