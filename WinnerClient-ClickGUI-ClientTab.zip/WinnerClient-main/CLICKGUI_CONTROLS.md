# WinnerClient ClickGUI

The ClickGUI has been rebuilt as a purple-accented, three-column interface for the project's Fabric 1.21.11 codebase.

## Controls
- Open the GUI with the existing Right Shift keybind.
- Use the left sidebar to switch categories.
- Click a module row to show that module's settings in the right panel. Click the selected row again to close the settings panel.
- Use the switch at the right edge of a module row to enable or disable it.
- Use the small keybind area beside the switch to assign a key. Press Escape to clear a binding or cancel text editing.
- Adjust booleans, number and integer sliders, modes, colors, and text settings in the right panel. The BlockESP Blocks setting continues to open its block picker.
- The Misc page includes both Misc and Client modules so no existing module category is hidden.
- Configs provides Save Config and Load Config actions for the existing `config/winnerclient.json` file.

Only the selected module's settings are expanded, in the right-hand panel. The module list itself stays compact and contains no inline settings controls.
