WinnerClient SpotifyHUD - KISMI, TEST EDILMEMIS TASARIM YAMASI

Temel: WinnerProjects/WinnerClient, main dalı, gözlemlenen commit d7370aef80a1ad035e7c964d4cc46e8283f32b96.
Minecraft 1.21.11, Fabric, Java 21 için kaynak düzeyinde hazırlandı.

KURULUM
1. Mevcut src/main/java/com/winnerclient/fabric/module/render/SpotifyHUD.java dosyasını yedekleyin.
2. ZIP içindeki aynı yoldaki SpotifyHUD.java ile değiştirin.
3. Kendi ortamınızda projeyi Gradle ile derleyin ve oyunda test edin.
4. ClickGUI > Render > SpotifyHUD üzerinden modülü açıp ayarları kontrol edin.

NE DEĞİŞTİ
- Koyu, yuvarlatılmış panel, kenarlık, NOW PLAYING, şarkı, sanatçı, durum ve dalga simgesi.
- Kaynak süre verisi sağlıyorsa geçen/kalan süre ve ilerleme çubuğu.
- Position ayarı adı/değerleri korunur. Width, Opacity, Accent, Footer ve Animations eklendi.
- Windows pencere başlığı ve mevcut spotify-helper.json tabanlı yerel/Web API denemeleri korunmuştur.
- Ağ işleri arka plan iş parçacığındadır; kapak veya shader dokusu üretilmez.

ÖNEMLİ SINIRLAR
- Yama derlenmedi ve masaüstünde/Android'de test edilmedi. Uyumluluk garanti edilmez.
- Sol kare gerçek albüm kapağı değildir. Kontroller, Spotify hesabı/OAuth, sözler, dokunmatik HUD ve Android medya entegrasyonu yoktur.
- Mojo Launcher üzerinde Android Spotify verisi alınmaz. Orijinal Windows kaynağı Android/Linux/macOS için çözüm değildir.
- Mevcut kaynakta oynatma durumu bulunmadığından ilerleme yalnızca elde edilen son ölçümü gösterir; interpolasyon yapılmaz.
- Yalnızca açılış fade-in vardır; modül yöneticisi kapalı modülleri çizmediği için kapanış fade-out yoktur.
- Orijinal yardımcı dosya/yerel API ve token varsayımları Spotify sürümüne göre çalışmayabilir.
- Kullanılan Minecraft fontu ve gerçek kapak/denetimlerin yokluğu nedeniyle referans görsel birebir değildir.
- ClickGUI sayısal slider'ları mevcut kaynakta sağ fare düğmesine bağlıdır.

Bu bir JAR değil, yalnızca kaynak dosyasıdır. Config dosyanızı yedeklemeniz önerilir.
